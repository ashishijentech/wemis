<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\DeviceService;
use App\Models\MapDeviceDetails;
use App\Models\Geofence;

class VehicalController extends Controller
{
    /**
     * Helper: Determine vehicle status & duration
     */
    private $deviceService;

    public function __construct(DeviceService $deviceService)
    {
        $this->deviceService = $deviceService;
    }


    /**
     * Vehicle list
     */
    public function vehicleList(Request $request)
    {
        $vehicles = $this->deviceService->vehicalList();
        return  response()->json($vehicles);
    }



    public function vehicalMap($vehicalNo)
    {
        return $this->deviceService->vehicalMap($vehicalNo);
    }

    public function matrixView()
    {
        return $this->deviceService->matrixView();
    }


    /**
     * Route playback for today
     */
    public function routePlayBack($imeiNo)
    {
        return $this->deviceService->routePlayBack($imeiNo);
    }

    /**
     * Stopage report for today
     */
    public function stopage($imeiNo)
    {
        return $this->deviceService->stopage($imeiNo);
    }

    /**
     * Overspeed report for today
     */
    public function overSpeed($imeiNo)
    {
       return response()->json($this->deviceService->overSpeed($imeiNo));
    }

    public function checkGeofence(Request $request, $imeiNo)
    {
        $request->validate([
            'latitude'  => 'required|numeric',
            'longitude' => 'required|numeric',
        ]);

        $lat = $request->input('latitude');
        $lng = $request->input('longitude');

        return response()->json($this->deviceService->checkGeofence($lat, $lng, $imeiNo));
    }

    public function sosAlert($imeiNo)
    {
        return $this->deviceService->sosAlert($imeiNo);
    }
    
   public function setGeoFence(Request $request){
        $request->validate([
            'vehicalNo' => 'required|string',
        ]);
        $device =  MapDeviceDetails::where('vehicle_registration_number',$request->vehicalNo)->first();
        $id = $device->id;

        Geofence::create([
            'map_device_details_id' => $id,
            'type' => $request->type,
            'center_latitude' => $request->center_latitude,
            'center_longitude' => $request->center_longitude,
            'radius' => $request->radius,
            'coordinates' => json_encode($request->coordinates),
        ]);
        return response()->json('GeoFence set successfully');
   }
}
