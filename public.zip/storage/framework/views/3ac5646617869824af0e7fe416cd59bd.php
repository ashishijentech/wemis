<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('subnav.element', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>;
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> <?php echo e(Session::get('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong> <?php echo e(Session::get('error')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="card-title mb-0">
                    <i class="fas fa-cubes me-2 text-primary"></i>Model No Management
                </h5>
                <p class="text-muted mb-0">
                    <i class="fas fa-info-circle me-1"></i>It shows the list of models number types and their details
                </p>
            </div>
            <table class="table table-bordered table-striped text-capitalize dataTable">
                <thead style="background-color: #260950;color:#fff">
                    <th>Si. no.</th>
                    <th>Element</th>
                    <th>Element type </th>
                    <th>Model no.</th>
                    <th>Voltage</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $modelNo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->elements->plucK('name')->first()); ?></td>
                            <td><?php echo e($item->type->pluck('type')->first()); ?></td>
                            <td><?php echo e($item->model_no); ?></td>
                            <td><?php echo e($item->voltage); ?></td>
                            <td>
                                <form action="<?php echo e(route('model_no.delete', $id = $item->id)); ?>" method="POST"
                                    style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a href="javascript:void(0);" class="btn" style="color: red"
                                        onclick="if(confirm('Are you sure you want to delete this item?')) { this.closest('form').submit(); }">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </form>

                                <a type="button" class="btn" data-bs-toggle="modal"
                                    data-bs-target="#editmodelNoModal<?php echo e($loop->iteration); ?>"><i
                                        class="fa-pen-to-square fa-solid"></i></a>
                            </td>
                        </tr>
                        <!--edit model type  Modal -->
                        <div class="modal fade" id="editmodelNoModal<?php echo e($loop->iteration); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h6 class="modal-title fs-5" id="exampleModalLabel">Edit Device Model Number</h6>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('model_no.update', $modelId = $item->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="element" value="<?php echo e($item->element_id); ?>">
                                            <input type="hidden" name="element_type" value="<?php echo e($item->element_id); ?>">

                                            <div class="mb-2">
                                                <label for="" class="form-label">Model No</label>
                                                <input type="text" class="form-control form-control-sm" name="model_no"
                                                    value="<?php echo e($item->model_no); ?>">
                                                <?php $__errorArgs = ['model_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-2">
                                                <label for="" class="form-label">Voltage</label>
                                                <input type="text" class="form-control form-control-sm" name="voltage"
                                                    value="<?php echo e($item->voltage); ?>">
                                                <?php $__errorArgs = ['voltage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <button type="submit" class="me-2 text-white btn btn-sm"
                                                style="background-color: #260950">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/we-trax/resources/views/backend/model/index.blade.php ENDPATH**/ ?>