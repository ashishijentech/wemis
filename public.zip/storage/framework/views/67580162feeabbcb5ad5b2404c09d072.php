
<?php $__env->startSection('content'); ?>
    <div class="conatiner-fluid">
        <div class="align-items-center row"
            style="background: linear-gradient(135deg, #2a0b5a 0%, #1a0638 100%); padding: 12px 20px;box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            <div class="col-md-6">
                <div class="d-flex align-items-center">
                    <i class="me-3 text-white fas fa-map-marked-alt fs-4"></i>
                    <h4 class="mb-0 text-white card-title" style="font-weight: 600; letter-spacing: 0.5px;">Documents
                    </h4>
                </div>
            </div>
        </div>
    </div>
    <?php
        $documents = [
            'Vehicle' => $device->vehicle,
            'RC' => $device->rc,
            'Device' => $device->device,
            'PAN' => $device->pan,
            'Aadhaar' => $device->aadhaar,
            'Invoice' => $device->invoice,
            'Signature' => $device->signature,
            'Panic Button' => $device->panic_button,
        ];
    ?>

    <div class="my-2">
        <div class="row">
            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex align-items-center">
                            <i class="fa fa-file me-2"></i>
                            <h6 class="mb-0"><?php echo e($name); ?></h6>
                        </div>
                        <div class="card-body text-center">
                            <img src="<?php echo e(asset('uploads/' . $file)); ?>" alt="<?php echo e($name); ?>"
                                class="img-fluid rounded mb-2" style="max-height:150px;">
                        </div>
                        <div class="card-footer text-center">
                            <a href="<?php echo e(asset('uploads/' . $file)); ?>" download class="btn btn-sm btn-primary">
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\backup-28-aug\we-trax\resources\views/backend/device/documents.blade.php ENDPATH**/ ?>