    <div class="modal fade" id="certificates" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Certificates</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('download.PDF')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <select name="type" class="form-select-sm form-select">
                                <option value="customer_copy">Customer Copy</option>
                                <option value="department_copy">Department Copy</option>
                            </select>
                        </div>
                        <input type="text" name="deviceId" id="deviceId" style="display: none">
                        <div class="mb-2">
                            <label for="" class="form-label">Leatter Head</label>
                            <select name="letterHead" class="form-select-sm form-select">
                                <option value="allow">Allow</option>
                                <option value="deny">Deny</option>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label for="" class="form-label">Certificate</label>
                            <select name="certificate" class="form-select-sm form-select">
                                <option value="installation">Installation</option>
                                <option value="warranty">Warranty</option>
                                <option value="fitment">Fitment</option>
                            </select>
                        </div>
                        <div style="text-align: right">
                            <button class="btn" style="background-color: #260950;color:#fff">Download</button>
                        </div>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\backup-28-aug\we-trax\resources\views/backend/device/partials/modal_certificates.blade.php ENDPATH**/ ?>