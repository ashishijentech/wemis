    <div class="modal fade" id="mapDevice" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                        Map Device
                    </h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('map.device.store')); ?>" method="post" enctype="multipart/form-data">
                        <!-- RFC Header -->
                        <?php echo csrf_field(); ?>
                        <div class="m-3 border border-secondary rounded">
                            <div class="bg-light p-2 border rounded-top">
                                <h5 class="mb-0 text-center">RFC Info</h5>
                            </div>

                            <!-- Form Body -->
                            <div class="p-3 border rounded">
                                <div class="row">
                                    <?php if(Auth::guard('manufacturer')->check()): ?>
                                        <!-- Country Dropdown -->
                                        <div class="form-group col-md-3">
                                            <label for="country">Country<span
                                                    class="text-danger badge">*</span></label>
                                            <select name="country" class="form-select-sm form-select country">
                                                <option disabled <?php if(true): echo 'selected'; endif; ?>>Choose Country
                                                </option>
                                                <option value="china" <?php if(old('country') == 'china'): echo 'selected'; endif; ?>>China
                                                </option>
                                                <option value="india" <?php if(old('country') == 'india'): echo 'selected'; endif; ?>>India
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- State Dropdown -->
                                        <div class="form-group col-md-3">
                                            <label for="state">State</label> <span class="text-danger badge">*</span>
                                            <select class="form-select-sm form-select state" name="state"
                                                id=""></select>
                                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Distributor Dropdown -->

                                        <div class="form-group col-md-3">
                                            <label for="distributor">Distributor</label><span
                                                class="text-danger badge">*</span>
                                            <Select class="form-select-sm form-select distributor" name="distributor">
                                                <option value="">Select Distributor</option>
                                            </Select>
                                            <?php $__errorArgs = ['distributor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <!-- Dealer Dropdown -->
                                        <div class="form-group col-md-3">
                                            <label for="dealer">Dealer </label><span
                                                class="text-danger badge">*</span>
                                            <Select class="form-select-sm form-select dealer" name="dealer">
                                                <option value="">Select Dealer</option>
                                            </Select>
                                            <?php $__errorArgs = ['dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    <?php elseif(Auth::guard('distributor')->check()): ?>
                                        <div class="form-group col-md-3">
                                            <label for="distributor">Dealer<span class="text-danger badge">*</span>
                                                <Select class="form-select-sm form-select dealer" name="dealer">
                                                    <option selected disabled>Select Dealer</option>
                                                    <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"
                                                            country="<?php echo e($item->country); ?>" state="<?php echo e($item->state); ?>"
                                                            dis="<?php echo e($item->district); ?>"
                                                            rto='<?php echo json_encode($item->rto_devision, 15, 512) ?>'>
                                                            <?php echo e($item->business_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </Select>
                                                <?php $__errorArgs = ['distributor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    <?php elseif(Auth::guard('dealer')->check()): ?>
                                        <div class="form-group col-md-3">
                                            <label for="distributor">Dealer<span class="text-danger badge">*</span>
                                                <Select class="form-select-sm form-select dealer" name="dealer">
                                                    <option selected disabled>Select Dealer</option>
                                                    <option value="<?php echo e(auth()->user()->id); ?>"
                                                        country="<?php echo e($item->country); ?>" state="<?php echo e($item->state); ?>"
                                                        dis="<?php echo e($item->district); ?>" rto='<?php echo json_encode($item->rto_devision, 15, 512) ?>'
                                                        readonly>
                                                        <?php echo e(auth()->user()->business_name); ?>

                                                    </option>
                                                </Select>
                                                <?php $__errorArgs = ['dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="form-group col-md-3">
                                            <label for="distributor">Dealer<span class="text-danger badge">*</span>
                                                <Select class="form-select-sm form-select dealer" name="dealer">
                                                    <option selected disabled>Select Dealer</option>
                                                    <option value="<?php echo e($dealer); ?>" country="<?php echo e($item->country); ?>"
                                                        state="<?php echo e($item->state); ?>" dis="<?php echo e($item->district); ?>"
                                                        rto='<?php echo json_encode($item->rto_devision, 15, 512) ?>' readonly>
                                                        <?php echo e($dealer->business_name); ?>

                                                    </option>
                                                </Select>
                                                <?php $__errorArgs = ['dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="m-3 border border-secondary rounded">
                            <!-- Device Info Header -->
                            <div class="bg-light p-2 border rounded-top">
                                <h5 class="mb-0 text-center">Device Info</h5>
                            </div>

                            <!-- Form Body -->
                            <div class="p-2 border rounded">
                                <div class="row">
                                    <!-- Device Type Dropdown -->
                                    <div class="form-group col-md-4">
                                        <label for="deviceType">Device Type </label><span
                                            class="text-danger badge">*</span>
                                        <select id="deviceType" name="deviceType" class="form-select-sm form-select">
                                            <option>Select Device Type</option>
                                            <option value="New">New</option>
                                            <option value="Renewal">Renewal</option>
                                            <!-- Add more device types here if needed -->
                                        </select>
                                        <?php $__errorArgs = ['deviceType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Device No Dropdown -->
                                    <div class="form-group col-md-4">
                                        <label for="deviceNo">Device No</label><span
                                            class="text-danger badge">*</span>
                                        <select name="deviceNo" class="form-select-sm form-select deviceno">
                                            <option>Select Device Number</option>
                                            <!-- Add more device numbers here if needed -->
                                        </select>
                                        <?php $__errorArgs = ['deviceNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Voltage Input (disabled) -->
                                    <div class="form-group col-md-4">
                                        <label for="voltage">Voltage</label>
                                        <input type="text" class="form-control form-control-sm voltage"
                                            name="voltage" placeholder="" readonly>
                                        <?php $__errorArgs = ['voltage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Element Type Input (disabled) -->
                                    <div class="form-group col-md-4">
                                        <label for="elementType">Element Type</label>
                                        <input type="text" class="form-control form-control-sm element_type"
                                            id="elementType" name="elementType" placeholder="" readonly>
                                    </div>

                                    <!-- Batch No Input (disabled) -->
                                    <div class="form-group col-md-4">
                                        <label for="batchNo">Batch No.</label>
                                        <input type="text" class="form-control form-control-sm batch_no"
                                            id="batchNo" name="batchNo" placeholder="" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="m-3 border border-secondary rounded">
                            <!-- Form Header -->
                            <div class="bg-light p-2 border rounded-top simInfo">
                                <h5 class="mb-0 text-center">SIM Info</h5>
                            </div>
                        </div>

                        <div class="m-3 border border-secondary rounded">
                            <div class="bg-light p-2 border rounded-top">
                                <h5 class="mb-0 text-center">
                                    Vehicle Info
                                </h5>
                            </div>
                            <div class="p-3 border rounded">
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="vehicleBirth">Vehicle Birth<span
                                                class="text-danger badge">*</span></label>
                                        <select id="vehicleBirth" name="vehicleBirth"
                                            class="form-select-sm form-select">
                                            <option selected value="Old">Old</option>
                                            <option value="New">New</option>
                                        </select>
                                        <?php $__errorArgs = ['vehicleBirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4" id="vaicleregNumber">
                                        <label for="regNumber">Registration No.<span
                                                class="text-danger badge">*</span></label>
                                        <input type="text" class="form-control form-control-sm" id="regNumber"
                                            name="regNumber" placeholder="Enter Registration Number">
                                        <?php $__errorArgs = ['regNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4" id="vaicledate">
                                        <label for="date">Date<span class="text-danger badge">*</span></label>
                                        <input type="date" class="form-control form-control-sm" id="date"
                                            name="regdate">
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="chassisNumber">Chassis Number<span
                                                class="text-danger badge">*</span></label>
                                        <input type="text" class="form-control form-control-sm" id="chassisNumber"
                                            name="chassisNumber" placeholder="Enter Chassis Number">
                                        <?php $__errorArgs = ['chassisNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="engineNumber">Engine Number<span
                                                class="text-danger badge">*</span></label>
                                        <input type="text" class="form-control form-control-sm" id="engineNumber"
                                            name="engineNumber" placeholder="Enter Engine Number">
                                        <?php $__errorArgs = ['engineNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="vehicleType">Vehicle Type<span
                                                class="text-danger badge">*</span></label>
                                        <select id="vehicleType" name="vehicleType"
                                            class="form-control form-control-sm">
                                            <option selected>Choose Vehicle Type</option>
                                            <option value="AUTO">AUTO</option>
                                            <option value="BUS">BUS</option>
                                            <option value="JCB">JCB</option>
                                            <option value="MAXI CAB">MAXI CAB</option>
                                            <option value="OIL TANK">OIL TANK</option>
                                            <option value="PICKUP">PICKUP</option>
                                            <option value="SCHOOL BUS">SCHOOL BUS</option>
                                            <option value="TANK TRUCK">TANK TRUCK</option>
                                            <option value="TAXI">TAXI</option>
                                            <option value="TEMPO">TEMPO</option>
                                            <option value="TRACTOR">TRACTOR</option>
                                            <option value="TRAILER TRUCK">TRAILER TRUCK</option>
                                            <option value="TRAVILER">TRAVILER</option>
                                            <option value="TRUCK">TRUCK</option>
                                        </select>
                                        <?php $__errorArgs = ['vehicleType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="makeModel">Make & Model<span
                                                class="text-danger badge">*</span></label>
                                        <input type="text" class="form-control form-control-sm" id="vaiModel"
                                            name="vaiclemodel" placeholder="Enter Make & Model">
                                        <?php $__errorArgs = ['vaiclemodel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="modelYear">Model Year<span
                                                class="text-danger badge">*</span></label>
                                        <input type="text" class="form-control" id="modelYear"
                                            name="vaimodelyear" placeholder="Enter Model Year">
                                        <?php $__errorArgs = ['vaimodelyear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="insurance">Insu. Renew date</label>
                                        <input type="date" class="form-control" id="insurance"
                                            name="vaicleinsurance">
                                        <?php $__errorArgs = ['vaicleinsurance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="panicButton">Pollution Renew date</label>
                                        <input type="date" class="form-control" id="panicButton"
                                            name="pollutiondate">
                                        <?php $__errorArgs = ['pollutiondate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="m-3 border border-secondary rounded">
                            <div class="bg-light p-3 border rounded-top">
                                <h5 class="mb-0 text-center">Customer Info</h5>
                            </div>
                            <div class="p-3 border rounded">
                                <div class="mb-4 row g-3">
                                    <!-- Customer Name -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="shadow-sm form-control" id="customerName"
                                                name="customerName" placeholder="Enter Name"
                                                value="<?php echo e(old('customerName')); ?>">
                                            <label for="customerName" class="text-muted small">Full Name <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['customerName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- Customer Email -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="email" class="shadow-sm form-control" id="email"
                                                name="customerEmail" placeholder="Enter Email"
                                                value="<?php echo e(old('customerEmail')); ?>">
                                            <label for="email" class="text-muted small">Email Address</label>
                                            <?php $__errorArgs = ['customerEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- Customer Mobile -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="tel" class="shadow-sm form-control" id="mobile"
                                                name="customerMobile" placeholder="Enter Mobile"
                                                value="<?php echo e(old('customerMobile')); ?>" autocomplete="off">
                                            <label for="mobile" class="text-muted small">Mobile Number <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['customerMobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- GSTIN Number -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="shadow-sm form-control" id="gstin"
                                                name="customergstin" placeholder="Enter GSTIN"
                                                value="<?php echo e(old('customergstin')); ?>">
                                            <label for="gstin" class="text-muted small">GSTIN Number</label>
                                            <?php $__errorArgs = ['customergstin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- Country -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="bg-light shadow-sm form-control"
                                                name="country" id="country" value="<?php echo e(old('country')); ?>" readonly
                                                autocomplete="off" onkeydown="return false;">
                                            <label for="country" class="text-muted small">Country <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- State -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="bg-light shadow-sm form-control"
                                                name="state" id="state" value="<?php echo e(old('state')); ?>" readonly
                                                autocomplete="off" onkeydown="return false;">
                                            <label for="state" class="text-muted small">State/Region <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4 row g-3">
                                    <!-- District -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="bg-light shadow-sm form-control"
                                                name="coustomerDistrict" id="district"
                                                value="<?php echo e(old('coustomerDistrict')); ?>" readonly autocomplete="off"
                                                onkeydown="return false;">
                                            <label for="district" class="text-muted small">District <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['coustomerDistrict'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- RTO Division -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <select class="shadow-sm form-select" name="rto_devision"
                                                id="rto_division">
                                                <option value="" selected disabled hidden>Select RTO Division
                                                </option>
                                                <!-- Options will be populated dynamically -->
                                            </select>
                                            <label for="rto_division" class="text-muted small">RTO Division <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['rto_division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>

                                    <!-- Pin Code -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="shadow-sm form-control"
                                                name="coustomerPincode" id="pincode"
                                                value="<?php echo e(old('coustomerPincode')); ?>">
                                            <label for="pincode" class="text-muted small">Pin Code <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['coustomerPincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- Address -->
                                    <div class="col-md-8">
                                        <div class="form-floating">
                                            <input type="text" class="shadow-sm form-control" id="address"
                                                name="coustomeraddress" placeholder=" "
                                                value="<?php echo e(old('coustomeraddress')); ?>">
                                            <label for="address" class="text-muted small">Complete Address <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['coustomeraddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- Aadhaar -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="shadow-sm form-control" id="aadhaar"
                                                name="customeraadhar" placeholder=" "
                                                value="<?php echo e(old('customeraadhar')); ?>">
                                            <label for="aadhaar" class="text-muted small">Aadhaar Number <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['customeraadhar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- PAN Number -->
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <input type="text" class="shadow-sm form-control" id="panNo"
                                                name="customerpanno" placeholder=" "
                                                value="<?php echo e(old('customerpanno')); ?>">
                                            <label for="panNo" class="text-muted small">PAN Number <span
                                                    class="text-danger">*</span></label>
                                            <?php $__errorArgs = ['customerpanno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="d-block invalid-feedback small"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="m-3 border border-secondary rounded">
                            <div class="bg-light p-2 border rounded-top">
                                <h5 class="mb-0 text-center">Packages</h5>
                            </div>
                            <div class="p-3 border rounded">
                                <div class="justify-content-center row">
                                    <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-2 col-md-3 Packages">
                                            <div class="shadow-sm h-100 text-center select-subscription"
                                                data-id="" style="width: 100%; cursor: pointer;">
                                                <!-- Added cursor:pointer for click indication -->
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between">
                                                        <h5 class="card-title fw-bold"><?php echo e($item->packageName); ?></h5>
                                                        <span class="packageId" hidden><?php echo e($item->id); ?></span>
                                                        <div class="d-flex align-items-center">
                                                            <i class="me-1 bi bi-clock"></i>
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                    <h5 class="mt-2"><i class="fa-solid fa-indian-rupee-sign"></i>
                                                        <?php echo e($item->price); ?></h5>
                                                    <p class="text-white"><?php echo e($item->billingCycle); ?></p>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['subscriptionpackage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="hidden" name="subscriptionpackage" id="subscriptionpackage">
                            </div>

                        </div>
                        <div class="m-3 border border-secondary rounded">
                            <div class="bg-light p-3 border rounded-top">
                                <div class="align-items-center row">
                                    <!-- Technician Info Title -->
                                    <div class="text-center col-md-6">
                                        <h5>Technician Info</h5>
                                    </div>

                                    <!-- Select Technician Dropdown -->
                                    <div class="col-md-3">
                                        <select class="form-select-sm form-select technician" name="technician">
                                            <option selected disabled>Select Technician</option>
                                        </select>
                                        <?php $__errorArgs = ['technician'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Add Technician Button -->
                                    <div class="text-end col-md-3">
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="p-2 row">
                                <div class="form-group col-md-4">
                                    <label for="firstName" class="form-label">Name <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" id="technician_name"
                                        name="name" placeholder="First Name" require readonly autocomplete="off">

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                
                                <div class="form-group col-md-4">
                                    <label for="email" class="form-label">Email <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" id="technician_email"
                                        name="techemail" placeholder="Email" readonly autocomplete="off">
                                </div>
                                
                                <div class="form-group col-md-4">
                                    <label for="mobile" class="form-label">Mobile <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" id="technician_mobile"
                                        name="techmobile" placeholder="Mobile" readonly autocomplete="off">
                                </div>
                                
                            </div>
                        </div>



                        <div class="m-3 border border-secondary rounded">
                            <div class="bg-light p-2 border rounded-top">
                                <h5 class="mb-0 text-center">Installation Detail</h5>
                            </div>
                            <div class="p-3 border rounded">
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="InvoiceNo" class="form-label">Invoice No<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control form-control-sm" id="InvoiceNo"
                                            name="InvoiceNo">
                                        <?php $__errorArgs = ['InvoiceNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="Vehicle KM Reading" class="form-label">Vehicle KM
                                            Reading<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control form-control-sm"
                                            id="VehicleKMReading" name="VehicleKMReading">
                                        <?php $__errorArgs = ['VehicleKMReading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="Driver License No" class="form-label">Driver License
                                            No<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control form-control-sm"
                                            id="DriverLicenseNo" name="DriverLicenseNo">
                                        <?php $__errorArgs = ['DriverLicenseNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="Mapped Date" class="form-label">Mapped Date<span
                                                class="text-danger">*</span></label>
                                        <input type="date" class="form-control form-control-sm" id="MappedDate"
                                            name="MappedDate">
                                        <?php $__errorArgs = ['MappedDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="No Of Panic Buttons" class="form-label">No Of Panic
                                            Buttons<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control form-control-sm"
                                            id="NoOfPanicButtons" name="NoOfPanicButtons">
                                        <?php $__errorArgs = ['NoOfPanicButtons'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="m-3 border border-secondary rounded">
                            <div class="bg-light p-2 border rounded-top">
                                <h5 class="mb-0 text-center">Vehicle Document (* document)</h5>
                            </div>
                            <div class="p-3 border rounded">
                                <p class="mb-2 text-danger text-center small">
                                    * File types supported: PNG, JPG, JPEG, PDF only. File size should be up to 6MB.
                                </p>

                                <div class="mb-3 row">
                                    <div class="col-md-4">
                                        <label for="vehicle" class="form-label">Vehicle</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="vehicle" name="vehicleimg" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-vehicle" class="border rounded img-fluid d-none"
                                                alt="Vehicle Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['vehicleimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="rc" class="form-label">RC</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="rc" name="vehiclerc" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-rc" class="border rounded img-fluid d-none"
                                                alt="RC Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['vehiclerc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="device" class="form-label">Device</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="device" name="vaicledeviceimg" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-device" class="border rounded img-fluid d-none"
                                                alt="Device Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['vaicledeviceimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <div class="col-md-4">
                                        <label for="pan" class="form-label">Pan Card</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="pan" name="pancardimg" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-pan" class="border rounded img-fluid d-none"
                                                alt="Pan Card Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['pancardimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="aadhaar" class="form-label">Aadhaar Card</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="aadhaar" name="aadharcardimg" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-aadhaar" class="border rounded img-fluid d-none"
                                                alt="Aadhaar Card Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['aadharcardimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="invoice" class="form-label">Invoice</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="invoice" name="invoiceimg" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-invoice" class="border rounded img-fluid d-none"
                                                alt="Invoice Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['invoiceimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <div class="col-md-4">
                                        <label for="signature" class="form-label">Signature</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="signature" name="signatureimg" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-signature" class="border rounded img-fluid d-none"
                                                alt="Signature Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['signatureimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="panic" class="form-label">Panic Button with Sticker</label>
                                        <input type="file" class="form-control form-control-sm preview-upload"
                                            id="panic" name="panicbuttonimg" accept=".png,.jpg,.jpeg,.pdf">
                                        <div class="mt-2 text-center">
                                            <img id="preview-panic" class="border rounded img-fluid d-none"
                                                alt="Panic Button Preview" style="max-height: 150px;">
                                        </div>
                                        <?php $__errorArgs = ['panicbuttonimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="my-2 text-center">
                            <button type="submit" class="btn"
                                style="background-color: #260950;color:#fff">Submit</button>
                            <button type="reset" class="btn btn-secondary">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\backup-28-aug\we-trax\resources\views/backend/device/partials/modal_map_device.blade.php ENDPATH**/ ?>