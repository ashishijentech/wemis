<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('subnav.element', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>;

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> <?php echo e(Session::get('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong> <?php echo e(Session::get('error')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="card-title mb-0">
                    <i class="fas fa-cubes me-2 text-primary"></i>Element Type Management
                </h5>
                <p class="text-muted mb-0">
                    <i class="fas fa-info-circle me-1"></i>List of all elements and their details
                </p>
            </div>
            <table class="table table-bordered dataTable">
                <thead class="text-white" style="background-color: #260950">
                    <tr>
                        <th>Si. No.</th>
                        <th>Element</th>
                        <th>Type</th>
                        <th>SIM Count</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $elementType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->elements->pluck('name')->first()); ?></td>
                            <td><?php echo e($item->type); ?></td>
                            <td>
                                <?php if($item->sim_count == null): ?>

                                    <span class="p-2" style="background-color: #260950;color:#fff;border-radius:50px"> <?php echo e("Not Required"); ?></span>
                                <?php else: ?>
                                    <?php echo e($item->sim_count); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#editModal<?php echo e($loop->iteration); ?>">
                                    <i class="fa-pen-to-square fa-solid"></i>
                                </button>
                                <form action="<?php echo e(route('element.type.delete', $elementTypeId = $item->id)); ?>" method="POST"
                                    style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this item?');"><i
                                            class="fa-solid fa-trash" style="color:#fff"></i></button>
                                </form>
                            </td>
                        </tr>
                        <!--edit element type  -->
                        <div class="modal fade" id="editModal<?php echo e($loop->iteration); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Element Type</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('element.type.update', $item->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>

                                            <!-- Select Element -->
                                            <div class="my-2">
                                                <label for="element" class="form-label">Select Element</label>
                                                <input type="text" name="elements" id="elementSelect<?php echo e($loop->iteration); ?>"
                                                    class="form-control form-control-sm"
                                                    value="<?php echo e($item->elements->pluck('name')->first()); ?>" readonly>
                                                <input type="hidden" name="element" id="elementSelect<?php echo e($loop->iteration); ?>"
                                                    class="form-control form-control-sm"
                                                    value="<?php echo e($item->elements->pluck('id')->first()); ?>" readonly>
                                                <?php $__errorArgs = ['element'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <!-- SIM Count (only show if it's required) -->
                                            <div class="my-2 sim-field<?php echo e($loop->iteration); ?>" style="display: none;">
                                                <label for="no_of_sim" class="form-label">No. of SIM</label>
                                                <input type="number" id="noOfSim<?php echo e($loop->iteration); ?>"
                                                    class="form-control form-control-sm" name="no_of_sim"
                                                    value="<?php echo e($item->sim_count ?? ''); ?>">
                                            </div>

                                            <!-- Type Field -->
                                            <div class="mb-2">
                                                <label for="type" class="form-label">Type</label>
                                                <input type="text" class="form-control form-control-sm" name="type"
                                                    value="<?php echo e($item->type); ?>" placeholder="Enter element type">
                                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <button type="submit" class="me-2 text-white btn btn-sm"
                                                style="background-color: #260950">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            <?php $__currentLoopData = $elementType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                let elementSelect<?php echo e($loop->iteration); ?> = $("#elementSelect<?php echo e($loop->iteration); ?>");
                let simField<?php echo e($loop->iteration); ?> = $(".sim-field<?php echo e($loop->iteration); ?>");
                let noOfSim<?php echo e($loop->iteration); ?> = $("#noOfSim<?php echo e($loop->iteration); ?>");

                // Show SIM field if a valid SIM count exists
                if (noOfSim<?php echo e($loop->iteration); ?>.val() !== "") {
                    simField<?php echo e($loop->iteration); ?>.show();
                }

                // Handle element change event
                elementSelect<?php echo e($loop->iteration); ?>.on("change", function () {
                    let selectedOption = $(this).find(":selected");
                    let simCount = selectedOption.data("sim-count");

                    if (simCount && simCount !== 0) {
                        noOfSim<?php echo e($loop->iteration); ?>.val(simCount);
                        simField<?php echo e($loop->iteration); ?>.show();
                    } else {
                        noOfSim<?php echo e($loop->iteration); ?>.val("");
                        simField<?php echo e($loop->iteration); ?>.hide();
                    }
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/we-trax/resources/views/backend/elementType/index.blade.php ENDPATH**/ ?>